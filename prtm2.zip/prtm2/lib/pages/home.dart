import 'package:flutter/material.dart';
import 'biodata_form_page.dart';

class HomeLaboratoryPage extends StatefulWidget {
  const HomeLaboratoryPage({super.key});

  @override
  State<HomeLaboratoryPage> createState() => _HomeLaboratoryPageState();
}

class _HomeLaboratoryPageState extends State<HomeLaboratoryPage> {
  final List<Map<String, String>> borrowedReports = [];
  final List<Map<String, String>> returnedReports = [];

  // Function to add a borrowed report
  void addBorrowedReport(String name, String npm, String angkatan, String reportTitle, String ownerName, String ownerNpm, String borrowDate) {
    setState(() {
      borrowedReports.add({
        'Nama': name,
        'NPM': npm,
        'Angkatan': angkatan,
        'JudulLaporan': reportTitle,
        'PemilikNama': ownerName,
        'PemilikNPM': ownerNpm,
        'TanggalPeminjaman': borrowDate,
      });
    });
  }

  // Function to mark report as returned
  void markAsReturned(int index) {
    setState(() {
      final returnedReport = borrowedReports.removeAt(index);
      returnedReports.add(returnedReport);
    });
  }

  // Function to edit borrowed report
  void editReport(int index, Map<String, String> updatedReport) {
    setState(() {
      borrowedReports[index] = updatedReport;
    });
  }

  // Function to delete borrowed report
  void deleteReport(int index) {
    setState(() {
      borrowedReports.removeAt(index);
    });
  }

  // Function to show Edit dialog
  void showEditDialog(int index) {
    final report = borrowedReports[index];
    final nameController = TextEditingController(text: report['Nama']);
    final npmController = TextEditingController(text: report['NPM']);
    final angkatanController = TextEditingController(text: report['Angkatan']);
    final reportTitleController = TextEditingController(text: report['JudulLaporan']);
    final ownerNameController = TextEditingController(text: report['PemilikNama']);
    final ownerNpmController = TextEditingController(text: report['PemilikNPM']);
    final borrowDateController = TextEditingController(text: report['TanggalPeminjaman']);

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Edit Laporan'),
          content: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TextField(
                  controller: nameController,
                  decoration: const InputDecoration(labelText: 'Nama'),
                ),
                TextField(
                  controller: npmController,
                  decoration: const InputDecoration(labelText: 'NPM'),
                ),
                TextField(
                  controller: angkatanController,
                  decoration: const InputDecoration(labelText: 'Angkatan'),
                ),
                TextField(
                  controller: reportTitleController,
                  decoration: const InputDecoration(labelText: 'Judul Laporan'),
                ),
                TextField(
                  controller: ownerNameController,
                  decoration: const InputDecoration(labelText: 'Pemilik Nama'),
                ),
                TextField(
                  controller: ownerNpmController,
                  decoration: const InputDecoration(labelText: 'Pemilik NPM'),
                ),
                TextField(
                  controller: borrowDateController,
                  decoration: const InputDecoration(labelText: 'Tanggal Peminjaman'),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                final updatedReport = {
                  'Nama': nameController.text,
                  'NPM': npmController.text,
                  'Angkatan': angkatanController.text,
                  'JudulLaporan': reportTitleController.text,
                  'PemilikNama': ownerNameController.text,
                  'PemilikNPM': ownerNpmController.text,
                  'TanggalPeminjaman': borrowDateController.text,
                };
                editReport(index, updatedReport);
                Navigator.of(context).pop();
              },
              child: const Text('Simpan'),
            ),
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Batal'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Peminjaman Laporan Laboratorium',
          style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, letterSpacing: 1.2),
        ),
        backgroundColor: Colors.green,
        elevation: 5,
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 30),
              const Text(
                'Selamat Datang di Sistem Peminjaman',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.black),
              ),
              const SizedBox(height: 10),
              const Text(
                'Kelola laporan laboratorium Anda dengan mudah.',
                style: TextStyle(fontSize: 16, color: Colors.grey, height: 1.5),
              ),
              const SizedBox(height: 20),
              GestureDetector(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => BiodataFormPage(
                        onSubmit: (name, npm, angkatan, reportTitle, ownerName, ownerNpm, borrowDate) {
                          addBorrowedReport(name, npm, angkatan, reportTitle, ownerName, ownerNpm, borrowDate);
                        },
                      ),
                    ),
                  );
                },
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 15),
                  decoration: BoxDecoration(
                    color: Colors.green,
                    borderRadius: BorderRadius.circular(30),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.2),
                        blurRadius: 10,
                        offset: const Offset(0, 5),
                      ),
                    ],
                  ),
                  child: const Text(
                    'Ajukan Peminjaman Baru',
                    style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
                    textAlign: TextAlign.center,
                  ),
                ),
              ),
              const SizedBox(height: 20),
              const Text(
                'Laporan yang Sedang Dipinjam',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.black),
              ),
              const SizedBox(height: 10),
              borrowedReports.isEmpty
                  ? const Center(child: Text('Tidak ada laporan yang sedang dipinjam'))
                  : ListView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: borrowedReports.length,
                      itemBuilder: (context, index) {
                        final report = borrowedReports[index];
                        return Card(
                          elevation: 3,
                          margin: const EdgeInsets.symmetric(vertical: 10),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(15),
                          ),
                          child: ListTile(
                            contentPadding: const EdgeInsets.all(15),
                            leading: const Icon(Icons.assignment, color: Colors.green, size: 30),
                            title: Text(
                              report['Nama'] ?? '',
                              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w500),
                            ),
                            subtitle: Text(
                                'NPM: ${report['NPM']}\nAngkatan: ${report['Angkatan']}\nJudul: ${report['JudulLaporan']}\nPemilik: ${report['PemilikNama']} (${report['PemilikNPM']})\nTanggal Peminjaman: ${report['TanggalPeminjaman']}'),
                            trailing: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                IconButton(
                                  icon: const Icon(Icons.edit, color: Colors.blue),
                                  onPressed: () => showEditDialog(index),
                                ),
                                IconButton(
                                  icon: const Icon(Icons.delete, color: Colors.red),
                                  onPressed: () => deleteReport(index),
                                ),
                                IconButton(
                                  icon: const Icon(Icons.check, color: Colors.green),
                                  onPressed: () => markAsReturned(index),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
              const SizedBox(height: 20),
              const Text(
                'Riwayat Peminjaman',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.black),
              ),
              const SizedBox(height: 10),
              returnedReports.isEmpty
                  ? const Center(child: Text('Belum ada laporan yang dikembalikan'))
                  : ListView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: returnedReports.length,
                      itemBuilder: (context, index) {
                        final report = returnedReports[index];
                        return Card(
                          elevation: 3,
                          margin: const EdgeInsets.symmetric(vertical: 10),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(15),
                          ),
                          child: ListTile(
                            contentPadding: const EdgeInsets.all(15),
                            leading: const Icon(Icons.assignment_turned_in, color: Colors.grey, size: 30),
                            title: Text(
                              report['Nama'] ?? '',
                              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w500),
                            ),
                            subtitle: Text(
                                'NPM: ${report['NPM']}\nAngkatan: ${report['Angkatan']}\nJudul: ${report['JudulLaporan']}\nPemilik: ${report['PemilikNama']} (${report['PemilikNPM']})\nTanggal Peminjaman: ${report['TanggalPeminjaman']}'),
                          ),
                        );
                      },
                    ),
              const SizedBox(height: 30),
            ],
          ),
        ),
      ),
    );
  }
}
