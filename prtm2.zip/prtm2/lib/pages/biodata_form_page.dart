import 'package:flutter/material.dart';

class BiodataFormPage extends StatelessWidget {
  final Function(String, String, String, String, String, String, String) onSubmit;
  final Map<String, String>? initialData;

  const BiodataFormPage({super.key, required this.onSubmit, this.initialData});

  @override
  Widget build(BuildContext context) {
    final nameController = TextEditingController(text: initialData?['Nama'] ?? '');
    final npmController = TextEditingController(text: initialData?['NPM'] ?? '');
    final angkatanController = TextEditingController(text: initialData?['Angkatan'] ?? '');
    final reportTitleController = TextEditingController(text: initialData?['JudulLaporan'] ?? '');
    final ownerNameController = TextEditingController(text: initialData?['PemilikNama'] ?? '');
    final ownerNpmController = TextEditingController(text: initialData?['PemilikNPM'] ?? '');
    final borrowDateController = TextEditingController(text: initialData?['TanggalPeminjaman'] ?? '');

    return Scaffold(
      appBar: AppBar(
        title: Text(
          initialData == null ? 'Isi Biodata' : 'Edit Biodata',
          style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.green,
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Lengkapi Data Diri Anda',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 20),
            TextField(
              controller: nameController,
              decoration: InputDecoration(
                labelText: 'Nama Lengkap',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
            ),
            const SizedBox(height: 20),
            TextField(
              controller: npmController,
              decoration: InputDecoration(
                labelText: 'NPM',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
            ),
            const SizedBox(height: 20),
            TextField(
              controller: angkatanController,
              decoration: InputDecoration(
                labelText: 'Angkatan',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
            ),
            const SizedBox(height: 20),
            TextField(
              controller: reportTitleController,
              decoration: InputDecoration(
                labelText: 'Judul Laporan',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
            ),
            const SizedBox(height: 20),
            TextField(
              controller: ownerNameController,
              decoration: InputDecoration(
                labelText: 'Nama Pemilik Laporan',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
            ),
            const SizedBox(height: 20),
            TextField(
              controller: ownerNpmController,
              decoration: InputDecoration(
                labelText: 'NPM Pemilik Laporan',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
            ),
            const SizedBox(height: 20),
            TextField(
              controller: borrowDateController,
              decoration: InputDecoration(
                labelText: 'Tanggal Peminjaman',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
            ),
            const SizedBox(height: 30),
            Center(
              child: ElevatedButton(
                onPressed: () {
                  if (nameController.text.isNotEmpty &&
                      npmController.text.isNotEmpty &&
                      angkatanController.text.isNotEmpty &&
                      reportTitleController.text.isNotEmpty &&
                      ownerNameController.text.isNotEmpty &&
                      ownerNpmController.text.isNotEmpty &&
                      borrowDateController.text.isNotEmpty) {
                    onSubmit(
                      nameController.text,
                      npmController.text,
                      angkatanController.text,
                      reportTitleController.text,
                      ownerNameController.text,
                      ownerNpmController.text,
                      borrowDateController.text,
                    );
                    Navigator.pop(context);
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Semua bidang harus diisi')),
                    );
                  }
                },
                child: const Text('Simpan'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
