import 'package:flutter/material.dart';

class BorrowingHistoryPage extends StatelessWidget {
  final List<Map<String, String>> borrowedReports;

  const BorrowingHistoryPage({super.key, required this.borrowedReports});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Riwayat Peminjaman'),
      ),
      body: ListView.builder(
        itemCount: borrowedReports.length,
        itemBuilder: (context, index) {
          final report = borrowedReports[index];
          return ListTile(
            title: Text(report['Nama'] ?? ''),
            subtitle: Text('NPM: ${report['NPM']}\nAngkatan: ${report['Angkatan']}'),
          );
        },
      ),
    );
  }
}
