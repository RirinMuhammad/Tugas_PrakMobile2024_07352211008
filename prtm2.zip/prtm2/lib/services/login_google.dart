import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';

/// Fungsi untuk login menggunakan Google
Future<User?> signInWithGoogle() async {
  final FirebaseAuth _auth = FirebaseAuth.instance;

  try {
    // Memulai proses login Google
    final GoogleSignInAccount? googleUser = await GoogleSignIn().signIn();
    if (googleUser == null) return null; // Jika login dibatalkan

    // Mendapatkan autentikasi dari Google
    final GoogleSignInAuthentication googleAuth =
        await googleUser.authentication;

    // Membuat kredensial Firebase dari token Google
    final AuthCredential credential = GoogleAuthProvider.credential(
      accessToken: googleAuth.accessToken,
      idToken: googleAuth.idToken,
    );

    // Login ke Firebase
    final UserCredential userCredential =
        await _auth.signInWithCredential(credential);

    return userCredential.user; // Mengembalikan pengguna yang login
  } catch (e) {
    // Menangani kesalahan login
    print('Login failed: $e');
    return null;
  }
}
